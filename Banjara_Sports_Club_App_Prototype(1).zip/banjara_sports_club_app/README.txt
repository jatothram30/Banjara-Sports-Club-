BANJARA SPORTS CLUB - ANDROID APK SOURCE

This is a starter Android wrapper around the club's web scoring prototype.
It is not yet a production multi-user live scoring service. Match and team data
are stored locally on the device. Login, cloud sync, public live score sharing,
and scorer approval are not implemented in this starter build.

HOW TO USE WITH GITHUB ON ANDROID:
1. Upload this ZIP file to the repository root as Banjara-Sports-Club-APK-Source.zip.
2. In GitHub, create a new file named exactly:
   .github/workflows/android-apk.yml
3. Paste the workflow from the separate file android-apk-workflow-copy.txt
   (included in this ZIP).
4. Commit the new file. Open the Actions tab, select Android APK, and run it.
5. When the run succeeds, open the run, scroll to Artifacts, and download
   Banjara-Sports-Club-debug-apk. Extract it and install app-debug.apk.
   Android may ask permission to install unknown apps.

IMPORTANT:
Uploading the ZIP alone does NOT build an APK. The workflow file must be
created in the GitHub repository as described above.
